import { Router } from "express";
import { db } from "@workspace/db";
import {
  serviceRequestsTable, usersTable, servicesTable,
  governoratesTable, areasTable, offersTable,
  technicianProfilesTable, technicianServicesTable, technicianAreasTable,
  notificationsTable, auditTrailTable, priceAdjustmentsTable,
} from "@workspace/db";
import { eq, and, desc, sql, inArray } from "drizzle-orm";
import { authenticate } from "../middlewares/auth";

const router = Router();

async function formatRequest(req: any) {
  return {
    id: req.id,
    customerId: req.customerId,
    serviceId: req.serviceId,
    selectedTechnicianId: req.selectedTechnicianId,
    status: req.status,
    fullName: req.fullName,
    mobile: req.mobile,
    governorateId: req.governorateId,
    areaId: req.areaId,
    address: req.address,
    description: req.description,
    images: req.images || [],
    agreedPrice: req.agreedPrice,
    adminNote: req.adminNote,
    createdAt: req.createdAt,
    updatedAt: req.updatedAt,
  };
}

// GET /api/requests
router.get("/requests", authenticate, async (req, res) => {
  try {
    const { status, serviceId, governorateId, areaId, customerId, technicianId, page = "1", limit = "20" } = req.query as any;
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    let conditions: any[] = [];
    const user = req.user!;

    if (user.role === "customer") {
      conditions.push(eq(serviceRequestsTable.customerId, user.id));
    } else if (user.role === "technician") {
      // Technician sees requests in their service/area
      const [profile] = await db.select().from(technicianProfilesTable).where(eq(technicianProfilesTable.userId, user.id)).limit(1);
      if (profile) {
        const techAreas = await db.select({ areaId: technicianAreasTable.areaId }).from(technicianAreasTable).where(eq(technicianAreasTable.technicianId, profile.id));
        const techServices = await db.select({ serviceId: technicianServicesTable.serviceId }).from(technicianServicesTable).where(eq(technicianServicesTable.technicianId, profile.id));
        const areaIds = techAreas.map((a) => a.areaId);
        const serviceIds = techServices.map((s) => s.serviceId);

        if (areaIds.length > 0) conditions.push(inArray(serviceRequestsTable.areaId, areaIds));
        if (serviceIds.length > 0) conditions.push(inArray(serviceRequestsTable.serviceId, serviceIds));
      }
    }

    if (status) conditions.push(eq(serviceRequestsTable.status, status));
    if (serviceId) conditions.push(eq(serviceRequestsTable.serviceId, parseInt(serviceId)));
    if (governorateId) conditions.push(eq(serviceRequestsTable.governorateId, parseInt(governorateId)));
    if (areaId) conditions.push(eq(serviceRequestsTable.areaId, parseInt(areaId)));
    if (customerId && (user.role === "admin" || user.role === "super_admin")) conditions.push(eq(serviceRequestsTable.customerId, parseInt(customerId)));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [{ total }] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(serviceRequestsTable)
      .where(where);

    const requests = await db
      .select()
      .from(serviceRequestsTable)
      .where(where)
      .orderBy(desc(serviceRequestsTable.createdAt))
      .limit(limitNum)
      .offset(offset);

    const [offerCounts] = [await db
      .select({ requestId: offersTable.requestId, count: sql<number>`count(*)::int` })
      .from(offersTable)
      .groupBy(offersTable.requestId)];

    const offerCountMap: Record<number, number> = {};
    offerCounts.forEach((o) => { offerCountMap[o.requestId] = o.count; });

    const data = requests.map((r) => ({ ...r, offersCount: offerCountMap[r.id] || 0 }));

    return res.json({ data, total, page: pageNum, limit: limitNum });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests
router.post("/requests", authenticate, async (req, res) => {
  try {
    if (req.user!.role !== "customer") return res.status(403).json({ error: "العملاء فقط يمكنهم إنشاء طلبات" });

    const { serviceId, fullName, mobile, governorateId, areaId, address, description, images } = req.body;
    if (!serviceId || !fullName || !mobile || !governorateId || !areaId || !address || !description) {
      return res.status(400).json({ error: "جميع الحقول مطلوبة" });
    }

    const [request] = await db
      .insert(serviceRequestsTable)
      .values({
        customerId: req.user!.id,
        serviceId: parseInt(serviceId),
        fullName, mobile,
        governorateId: parseInt(governorateId),
        areaId: parseInt(areaId),
        address, description,
        images: images || [],
        status: "pending",
      })
      .returning();

    return res.status(201).json(request);
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// GET /api/requests/:id
router.get("/requests/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    const [request] = await db.select().from(serviceRequestsTable).where(eq(serviceRequestsTable.id, id)).limit(1);
    if (!request) return res.status(404).json({ error: "الطلب غير موجود" });

    // Load related
    const [service] = await db.select().from(servicesTable).where(eq(servicesTable.id, request.serviceId)).limit(1);
    const [governorate] = await db.select().from(governoratesTable).where(eq(governoratesTable.id, request.governorateId)).limit(1);
    const [area] = await db.select().from(areasTable).where(eq(areasTable.id, request.areaId)).limit(1);
    const [customer] = await db.select({ id: usersTable.id, fullName: usersTable.fullName, mobile: usersTable.mobile, profileImage: usersTable.profileImage }).from(usersTable).where(eq(usersTable.id, request.customerId)).limit(1);

    const [offerCount] = await db.select({ count: sql<number>`count(*)::int` }).from(offersTable).where(eq(offersTable.requestId, id));

    return res.json({
      ...request,
      service,
      governorate,
      area,
      customer,
      offersCount: offerCount?.count || 0,
    });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// PATCH /api/requests/:id
router.patch("/requests/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    const { status, adminNote } = req.body;

    const [request] = await db.select().from(serviceRequestsTable).where(eq(serviceRequestsTable.id, id)).limit(1);
    if (!request) return res.status(404).json({ error: "الطلب غير موجود" });

    if (req.user!.role !== "admin" && req.user!.role !== "super_admin") {
      return res.status(403).json({ error: "غير مسموح" });
    }

    const oldStatus = request.status;
    const [updated] = await db
      .update(serviceRequestsTable)
      .set({ status, adminNote, updatedAt: new Date() })
      .where(eq(serviceRequestsTable.id, id))
      .returning();

    if (oldStatus !== status) {
      await db.insert(auditTrailTable).values({
        requestId: id,
        changedBy: req.user!.id,
        fieldName: "status",
        oldValue: oldStatus,
        newValue: status,
      });
    }

    return res.json(updated);
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests/:id/cancel
router.post("/requests/:id/cancel", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    const { reason } = req.body;
    const user = req.user!;

    let status: string;
    if (user.role === "customer") status = "cancelled_by_customer";
    else if (user.role === "technician") status = "cancelled_by_technician";
    else status = "cancelled_by_admin";

    await db
      .update(serviceRequestsTable)
      .set({ status: status as any, cancelReason: reason, updatedAt: new Date() })
      .where(eq(serviceRequestsTable.id, id));

    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests/:id/complete
router.post("/requests/:id/complete", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    await db
      .update(serviceRequestsTable)
      .set({ status: "completed", updatedAt: new Date() })
      .where(eq(serviceRequestsTable.id, id));
    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests/:id/price-adjustment
router.post("/requests/:id/price-adjustment", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    const { newPrice, newDescription, images } = req.body;

    await db.insert(priceAdjustmentsTable).values({
      requestId: id,
      newPrice: newPrice.toString(),
      newDescription,
      images: images || [],
      status: "pending",
    });

    await db
      .update(serviceRequestsTable)
      .set({ status: "price_change_requested", updatedAt: new Date() })
      .where(eq(serviceRequestsTable.id, id));

    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests/:id/price-adjustment/respond
router.post("/requests/:id/price-adjustment/respond", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    const { approved } = req.body;

    if (approved) {
      const [adj] = await db
        .select()
        .from(priceAdjustmentsTable)
        .where(and(eq(priceAdjustmentsTable.requestId, id), eq(priceAdjustmentsTable.status, "pending")))
        .orderBy(desc(priceAdjustmentsTable.createdAt))
        .limit(1);

      if (adj) {
        await db.update(serviceRequestsTable).set({
          agreedPrice: adj.newPrice,
          status: "in_progress",
          updatedAt: new Date(),
        }).where(eq(serviceRequestsTable.id, id));
        await db.update(priceAdjustmentsTable).set({ status: "approved" }).where(eq(priceAdjustmentsTable.id, adj.id));
      }
    } else {
      await db.update(serviceRequestsTable).set({ status: "in_progress", updatedAt: new Date() }).where(eq(serviceRequestsTable.id, id));
      await db.update(priceAdjustmentsTable).set({ status: "rejected" }).where(and(eq(priceAdjustmentsTable.requestId, id), eq(priceAdjustmentsTable.status, "pending")));
    }

    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

export default router;
