import { Router } from "express";
import { db } from "@workspace/db";
import {
  offersTable, serviceRequestsTable, usersTable,
  technicianProfilesTable, commissionsTable, pointTransactionsTable,
  notificationsTable, ratingsTable,
} from "@workspace/db";
import { eq, and, avg, count, desc } from "drizzle-orm";
import { authenticate } from "../middlewares/auth";

const router = Router();

// GET /api/requests/:requestId/offers
router.get("/requests/:requestId/offers", authenticate, async (req, res) => {
  try {
    const requestId = parseInt(req.params["requestId"] as string);
    const offers = await db
      .select()
      .from(offersTable)
      .where(eq(offersTable.requestId, requestId))
      .orderBy(offersTable.createdAt);

    const result = await Promise.all(
      offers.map(async (offer) => {
        const [tech] = await db
          .select({ id: usersTable.id, fullName: usersTable.fullName, profileImage: usersTable.profileImage, mobile: usersTable.mobile })
          .from(usersTable)
          .where(eq(usersTable.id, offer.technicianId))
          .limit(1);

        const ratingStats = await db
          .select({ avg: avg(ratingsTable.stars), count: count() })
          .from(ratingsTable)
          .where(eq(ratingsTable.technicianId, offer.technicianId));

        return {
          ...offer,
          technician: tech ? {
            ...tech,
            averageRating: parseFloat(ratingStats[0]?.avg ?? "0"),
            reviewCount: ratingStats[0]?.count ?? 0,
          } : null,
        };
      })
    );

    return res.json(result);
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests/:requestId/offers
router.post("/requests/:requestId/offers", authenticate, async (req, res) => {
  try {
    if (req.user!.role !== "technician") {
      return res.status(403).json({ error: "الفنيون فقط يمكنهم تقديم عروض" });
    }

    const requestId = parseInt(req.params["requestId"] as string);
    const { price, notes } = req.body;
    if (!price) return res.status(400).json({ error: "السعر مطلوب" });

    // Check if already submitted
    const existing = await db
      .select()
      .from(offersTable)
      .where(and(eq(offersTable.requestId, requestId), eq(offersTable.technicianId, req.user!.id)))
      .limit(1);
    if (existing.length > 0) return res.status(400).json({ error: "لقد قدمت عرضاً لهذا الطلب مسبقاً" });

    // Check points balance
    const [profile] = await db
      .select()
      .from(technicianProfilesTable)
      .where(eq(technicianProfilesTable.userId, req.user!.id))
      .limit(1);

    if (!profile) return res.status(404).json({ error: "الفني غير موجود" });

    // Get commission for this request
    const [request] = await db.select().from(serviceRequestsTable).where(eq(serviceRequestsTable.id, requestId)).limit(1);
    if (!request) return res.status(404).json({ error: "الطلب غير موجود" });

    const commissions = await db
      .select()
      .from(commissionsTable)
      .where(eq(commissionsTable.serviceId, request.serviceId))
      .limit(1);

    const commission = commissions[0];
    let requiredPoints = 0;
    if (commission) {
      if (commission.type === "fixed") {
        requiredPoints = parseFloat(commission.value);
      } else {
        requiredPoints = Math.ceil((parseFloat(price) * parseFloat(commission.value)) / 100);
      }
    }

    if (profile.pointsBalance < requiredPoints) {
      return res.status(400).json({
        error: `رصيد النقاط غير كافٍ. مطلوب ${requiredPoints} نقطة، رصيدك الحالي ${profile.pointsBalance} نقطة`
      });
    }

    const [offer] = await db
      .insert(offersTable)
      .values({ requestId, technicianId: req.user!.id, price: price.toString(), notes, status: "pending" })
      .returning();

    // Update request status
    await db
      .update(serviceRequestsTable)
      .set({ status: "offers_received", updatedAt: new Date() })
      .where(eq(serviceRequestsTable.id, requestId));

    // Notify customer
    await db.insert(notificationsTable).values({
      userId: request.customerId,
      title: "عرض جديد",
      body: "تم تقديم عرض جديد على طلبك",
      type: "new_offer",
      relatedId: requestId,
    });

    return res.status(201).json(offer);
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// PATCH /api/requests/:requestId/offers/:offerId
router.patch("/requests/:requestId/offers/:offerId", authenticate, async (req, res) => {
  try {
    const offerId = parseInt(req.params["offerId"] as string);
    const { price, notes } = req.body;
    const [offer] = await db
      .update(offersTable)
      .set({ price: price?.toString(), notes, updatedAt: new Date() })
      .where(and(eq(offersTable.id, offerId), eq(offersTable.technicianId, req.user!.id)))
      .returning();
    if (!offer) return res.status(404).json({ error: "العرض غير موجود" });
    return res.json(offer);
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/requests/:requestId/offers/:offerId/select
router.post("/requests/:requestId/offers/:offerId/select", authenticate, async (req, res) => {
  try {
    if (req.user!.role !== "customer") return res.status(403).json({ error: "العملاء فقط يمكنهم اختيار الفني" });

    const requestId = parseInt(req.params["requestId"] as string);
    const offerId = parseInt(req.params["offerId"] as string);

    const [request] = await db.select().from(serviceRequestsTable).where(eq(serviceRequestsTable.id, requestId)).limit(1);
    if (!request) return res.status(404).json({ error: "الطلب غير موجود" });
    if (request.customerId !== req.user!.id) return res.status(403).json({ error: "غير مسموح" });

    const [offer] = await db.select().from(offersTable).where(eq(offersTable.id, offerId)).limit(1);
    if (!offer) return res.status(404).json({ error: "العرض غير موجود" });

    // Select this offer
    await db.update(offersTable).set({ status: "selected" }).where(eq(offersTable.id, offerId));
    // Reject others
    await db.update(offersTable).set({ status: "rejected" }).where(and(eq(offersTable.requestId, requestId), eq(offersTable.status, "pending")));

    // Update request
    await db.update(serviceRequestsTable).set({
      status: "technician_selected",
      selectedTechnicianId: offer.technicianId,
      agreedPrice: offer.price,
      updatedAt: new Date(),
    }).where(eq(serviceRequestsTable.id, requestId));

    // Notify technician
    await db.insert(notificationsTable).values({
      userId: offer.technicianId,
      title: "تم اختيارك",
      body: "تم اختيارك من قبل العميل لتنفيذ الطلب",
      type: "technician_selected",
      relatedId: requestId,
    });

    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err });
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

export default router;
