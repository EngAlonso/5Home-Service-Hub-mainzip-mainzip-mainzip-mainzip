import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import {
  usersTable,
  technicianProfilesTable,
  technicianServicesTable,
  technicianAreasTable,
  adminPermissionsTable,
} from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { authenticate, signToken } from "../middlewares/auth";

const router = Router();

function formatUser(user: typeof usersTable.$inferSelect, profile?: any) {
  return {
    id: user.id,
    fullName: user.fullName,
    mobile: user.mobile,
    email: user.email,
    role: user.role,
    status: user.status,
    profileImage: user.profileImage,
    jobTitle: user.jobTitle,
    createdAt: user.createdAt,
    suspensionReason: user.suspensionReason,
    bannedUntil: (user as any).bannedUntil,
    technicianProfile: profile || null,
  };
}

async function getPermissions(userId: number, role: string): Promise<string[]> {
  if (role === "super_admin") return ["*"];
  const rows = await db
    .select()
    .from(adminPermissionsTable)
    .where(eq(adminPermissionsTable.adminId, userId))
    .limit(1);
  return rows[0]?.permissions || [];
}

// POST /api/auth/register/customer
router.post("/auth/register/customer", async (req, res) => {
  try {
    const { fullName, mobile, password } = req.body;
    if (!fullName || !mobile || !password) {
      return res.status(400).json({ error: "جميع الحقول مطلوبة" });
    }
    const existing = await db.select().from(usersTable).where(eq(usersTable.mobile, mobile)).limit(1);
    if (existing.length > 0) return res.status(400).json({ error: "رقم الهاتف مسجل مسبقاً" });
    const passwordHash = await bcrypt.hash(password, 10);
    const [user] = await db
      .insert(usersTable)
      .values({ fullName, mobile, passwordHash, role: "customer", status: "active" })
      .returning();
    const token = signToken({ id: user.id, role: user.role, mobile: user.mobile });
    return res.status(201).json({ token, user: formatUser(user), permissions: [] });
  } catch (err) {
    req.log.error({ err }, "register customer error");
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/auth/register/technician
router.post("/auth/register/technician", async (req, res) => {
  try {
    const {
      fullName, mobile, password, nationalId,
      personalPhoto, nationalIdFront, nationalIdBack,
      serviceIds, areaIds, primaryAreaId,
    } = req.body;
    if (!fullName || !mobile || !password || !nationalId) {
      return res.status(400).json({ error: "جميع الحقول المطلوبة يجب ملؤها" });
    }
    const existing = await db.select().from(usersTable).where(eq(usersTable.mobile, mobile)).limit(1);
    if (existing.length > 0) return res.status(400).json({ error: "رقم الهاتف مسجل مسبقاً" });

    const passwordHash = await bcrypt.hash(password, 10);
    const [user] = await db
      .insert(usersTable)
      .values({ fullName, mobile, passwordHash, role: "technician", status: "pending" })
      .returning();

    const [profile] = await db
      .insert(technicianProfilesTable)
      .values({
        userId: user.id,
        nationalId,
        personalPhoto: personalPhoto || null,
        nationalIdFront: nationalIdFront || null,
        nationalIdBack: nationalIdBack || null,
        approvalStatus: "pending",
        primaryAreaId: primaryAreaId || null,
      })
      .returning();

    if (serviceIds && Array.isArray(serviceIds)) {
      for (const sid of serviceIds) {
        await db.insert(technicianServicesTable).values({ technicianId: profile.id, serviceId: sid });
      }
    }
    if (areaIds && Array.isArray(areaIds)) {
      for (const aid of areaIds) {
        await db.insert(technicianAreasTable).values({ technicianId: profile.id, areaId: aid });
      }
    }

    const token = signToken({ id: user.id, role: user.role, mobile: user.mobile });
    return res.status(201).json({ token, user: formatUser(user, { ...profile }), permissions: [] });
  } catch (err) {
    req.log.error({ err }, "register technician error");
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/auth/login
router.post("/auth/login", async (req, res) => {
  try {
    const { mobile, password } = req.body;
    if (!mobile || !password) return res.status(400).json({ error: "رقم الهاتف وكلمة المرور مطلوبان" });

    const users = await db.select().from(usersTable).where(eq(usersTable.mobile, mobile)).limit(1);
    if (users.length === 0) return res.status(401).json({ error: "رقم الهاتف أو كلمة المرور غير صحيحة" });

    const user = users[0];
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "رقم الهاتف أو كلمة المرور غير صحيحة" });

    // Check permanent ban
    if (user.status === "banned") {
      return res.status(403).json({ error: `الحساب محظور بشكل دائم. السبب: ${user.suspensionReason || "مخالفة السياسة"}` });
    }

    // Check temporary ban (bannedUntil)
    if (user.status === "suspended") {
      const bannedUntil = (user as any).bannedUntil as Date | null;
      if (bannedUntil) {
        const now = new Date();
        if (bannedUntil > now) {
          return res.status(403).json({
            error: `الحساب موقوف حتى ${bannedUntil.toLocaleDateString("ar-EG")}. السبب: ${user.suspensionReason || "مخالفة السياسة"}`,
          });
        } else {
          await db.update(usersTable).set({ status: "active", suspensionReason: null, updatedAt: new Date() }).where(eq(usersTable.id, user.id));
        }
      } else {
        return res.status(403).json({ error: `الحساب موقوف. السبب: ${user.suspensionReason || "تواصل مع الدعم الفني"}` });
      }
    }

    // Fetch technician profile if needed
    let profile = null;
    if (user.role === "technician") {
      const profiles = await db.select().from(technicianProfilesTable).where(eq(technicianProfilesTable.userId, user.id)).limit(1);
      if (profiles.length > 0) profile = profiles[0];
    }

    // Fetch permissions for admins
    let permissions: string[] = [];
    if (user.role === "admin" || user.role === "super_admin") {
      permissions = await getPermissions(user.id, user.role);
    }

    const token = signToken({ id: user.id, role: user.role, mobile: user.mobile });
    return res.json({ token, user: formatUser(user, profile), permissions });
  } catch (err) {
    req.log.error({ err }, "login error");
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

// POST /api/auth/logout
router.post("/auth/logout", (_req, res) => {
  res.json({ success: true });
});

// GET /api/auth/me
router.get("/auth/me", authenticate, async (req, res) => {
  try {
    const users = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id)).limit(1);
    if (users.length === 0) return res.status(404).json({ error: "المستخدم غير موجود" });

    const user = users[0];
    let profile = null;
    if (user.role === "technician") {
      const profiles = await db.select().from(technicianProfilesTable).where(eq(technicianProfilesTable.userId, user.id)).limit(1);
      if (profiles.length > 0) profile = profiles[0];
    }

    let permissions: string[] = [];
    if (user.role === "admin" || user.role === "super_admin") {
      permissions = await getPermissions(user.id, user.role);
    }

    return res.json({ ...formatUser(user, profile), permissions });
  } catch (err) {
    req.log.error({ err }, "getMe error");
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

export default router;
