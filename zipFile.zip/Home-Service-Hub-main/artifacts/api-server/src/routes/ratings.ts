import { Router } from "express";
import { db } from "@workspace/db";
import { ratingsTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { authenticate, requireRole } from "../middlewares/auth";

const router = Router();

router.get("/ratings", async (req, res) => {
  try {
    const { technicianId, customerId } = req.query as any;
    let rows = await db
      .select({ rating: ratingsTable, customer: usersTable })
      .from(ratingsTable)
      .leftJoin(usersTable, eq(ratingsTable.customerId, usersTable.id))
      .orderBy(desc(ratingsTable.createdAt));

    if (technicianId) rows = rows.filter((r) => r.rating.technicianId === parseInt(technicianId));
    if (customerId) rows = rows.filter((r) => r.rating.customerId === parseInt(customerId));

    return res.json(rows.map(({ rating, customer }) => ({
      ...rating,
      customer: customer ? { id: customer.id, fullName: customer.fullName, profileImage: customer.profileImage } : null,
    })));
  } catch (err) {
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

router.post("/ratings", authenticate, async (req, res) => {
  try {
    if (req.user!.role !== "customer") return res.status(403).json({ error: "العملاء فقط يمكنهم التقييم" });
    const { requestId, technicianId, stars, review } = req.body;
    if (!requestId || !technicianId || !stars) return res.status(400).json({ error: "البيانات مطلوبة" });
    if (stars < 1 || stars > 5) return res.status(400).json({ error: "التقييم يجب أن يكون بين 1 و5" });

    const [rating] = await db
      .insert(ratingsTable)
      .values({ requestId, customerId: req.user!.id, technicianId, stars, review })
      .returning();
    return res.status(201).json(rating);
  } catch (err) {
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

router.delete("/ratings/:id", authenticate, requireRole("admin", "super_admin"), async (req, res) => {
  try {
    const id = parseInt(req.params["id"] as string);
    await db.delete(ratingsTable).where(eq(ratingsTable.id, id));
    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({ error: "حدث خطأ في الخادم" });
  }
});

export default router;
