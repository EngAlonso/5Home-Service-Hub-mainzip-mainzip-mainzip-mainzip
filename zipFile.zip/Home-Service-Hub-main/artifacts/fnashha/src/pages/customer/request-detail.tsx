import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  useGetRequest, getGetRequestQueryKey,
  useListOffers, getListOffersQueryKey,
  useSelectOffer,
  useCancelRequest,
  useCompleteRequest,
  useCreateRating,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { REQUEST_STATUS_MAP, OFFER_STATUS_MAP } from "@/lib/status";
import { Star, MessageCircle, CheckCircle, XCircle, MapPin, Phone, Clock } from "lucide-react";

export default function CustomerRequestDetail({ id }: { id: string }) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { currentUser } = useAuth();
  const reqId = parseInt(id);

  const { data: request, isLoading } = useGetRequest(reqId, {
    query: { enabled: !!reqId, queryKey: getGetRequestQueryKey(reqId) },
  });

  const { data: offers = [] } = useListOffers(
    { requestId: reqId } as any,
    { query: { enabled: !!reqId, queryKey: getListOffersQueryKey({ requestId: reqId } as any) } }
  );

  const selectMutation = useSelectOffer();
  const cancelMutation = useCancelRequest();
  const completeMutation = useCompleteRequest();
  const ratingMutation = useCreateRating();

  const [ratingStars, setRatingStars] = useState(5);
  const [ratingReview, setRatingReview] = useState("");
  const [showRating, setShowRating] = useState(false);

  if (isLoading) {
    return (
      <div className="p-6 max-w-3xl mx-auto space-y-4">
        {[1, 2].map((i) => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}
      </div>
    );
  }

  if (!request) {
    return <div className="p-6 text-center text-muted-foreground">الطلب غير موجود</div>;
  }

  const req = request as any;
  const statusInfo = REQUEST_STATUS_MAP[req.status] || { label: req.status, color: "bg-gray-100 text-gray-600" };
  const isActive = !["completed", "cancelled_by_customer", "cancelled_by_technician", "cancelled_by_admin"].includes(req.status);
  const canChat = ["technician_selected", "in_progress", "price_change_requested", "waiting_approval"].includes(req.status);

  const handleSelectOffer = (offerId: number) => {
    selectMutation.mutate(
      { requestId: reqId, offerId, data: {} as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRequestQueryKey(reqId) });
          queryClient.invalidateQueries({ queryKey: getListOffersQueryKey({ requestId: reqId } as any) });
          toast({ title: "تم اختيار الفني", description: "يمكنك الآن التواصل مع الفني" });
        },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  const handleCancel = () => {
    cancelMutation.mutate(
      { id: reqId, data: { reason: "إلغاء من قبل العميل" } as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRequestQueryKey(reqId) });
          toast({ title: "تم إلغاء الطلب" });
        },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  const handleComplete = () => {
    completeMutation.mutate(
      { id: reqId, data: {} as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRequestQueryKey(reqId) });
          toast({ title: "تم تأكيد الإكمال" });
          setShowRating(true);
        },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  const handleSubmitRating = () => {
    ratingMutation.mutate(
      {
        data: {
          requestId: reqId,
          technicianId: req.selectedTechnicianId,
          stars: ratingStars,
          review: ratingReview,
        } as any
      },
      {
        onSuccess: () => {
          toast({ title: "شكراً على تقييمك" });
          setShowRating(false);
        },
        onError: () => setShowRating(false),
      }
    );
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">تفاصيل الطلب #{req.id}</h1>
          <Badge className={`mt-2 ${statusInfo.color} border-0`}>{statusInfo.label}</Badge>
        </div>
        <div className="flex gap-2">
          {canChat && (
            <Link href={`/customer/chat/${reqId}`}>
              <Button size="sm" data-testid="button-chat">
                <MessageCircle className="w-4 h-4 ms-2" />
                المحادثة
              </Button>
            </Link>
          )}
          {req.status === "in_progress" && (
            <Button size="sm" variant="outline" onClick={handleComplete} disabled={completeMutation.isPending} data-testid="button-complete">
              <CheckCircle className="w-4 h-4 ms-2" />
              تأكيد الإنجاز
            </Button>
          )}
          {isActive && req.status === "pending" && (
            <Button size="sm" variant="destructive" onClick={handleCancel} disabled={cancelMutation.isPending} data-testid="button-cancel">
              <XCircle className="w-4 h-4 ms-2" />
              إلغاء
            </Button>
          )}
        </div>
      </div>

      {/* Details */}
      <Card>
        <CardHeader><CardTitle className="text-base">بيانات الطلب</CardTitle></CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex items-start gap-2">
            <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
            <span>{req.address}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <span>{req.mobile}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <span>{new Date(req.createdAt).toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" })}</span>
          </div>
          <div className="pt-2 border-t">
            <p className="text-muted-foreground mb-1">الوصف:</p>
            <p className="text-foreground">{req.description}</p>
          </div>
          {req.agreedPrice && (
            <div className="pt-2 border-t">
              <p className="font-semibold text-primary text-lg">السعر المتفق عليه: {req.agreedPrice} جنيه</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Offers */}
      {req.status !== "pending" || (offers as any[]).length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">العروض المقدمة ({(offers as any[]).length})</CardTitle>
          </CardHeader>
          <CardContent>
            {(offers as any[]).length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">لا توجد عروض بعد</p>
            ) : (
              <div className="space-y-4">
                {(offers as any[]).map((offer: any) => {
                  const offerStatus = OFFER_STATUS_MAP[offer.status] || { label: offer.status, color: "bg-gray-100" };
                  return (
                    <div key={offer.id} className="border rounded-xl p-4" data-testid={`card-offer-${offer.id}`}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="text-xs font-bold text-primary">{offer.technician?.fullName?.[0]}</span>
                            </div>
                            <div>
                              <p className="font-semibold text-sm">{offer.technician?.fullName}</p>
                              {offer.technician?.averageRating > 0 && (
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <Star className="w-3 h-3 fill-primary text-primary" />
                                  {offer.technician.averageRating.toFixed(1)} ({offer.technician.reviewCount} تقييم)
                                </div>
                              )}
                            </div>
                          </div>
                          {offer.notes && <p className="text-sm text-muted-foreground">{offer.notes}</p>}
                        </div>
                        <div className="text-left">
                          <p className="text-xl font-black text-primary">{offer.price} جنيه</p>
                          <Badge className={`text-xs ${offerStatus.color} border-0 mt-1`}>{offerStatus.label}</Badge>
                        </div>
                      </div>
                      {offer.status === "pending" && req.status === "offers_received" && (
                        <Button
                          className="w-full mt-3 font-semibold"
                          size="sm"
                          onClick={() => handleSelectOffer(offer.id)}
                          disabled={selectMutation.isPending}
                          data-testid={`button-select-offer-${offer.id}`}
                        >
                          اختيار هذا الفني
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      ) : null}

      {/* Rating modal */}
      {showRating && (
        <Card className="border-primary">
          <CardHeader><CardTitle className="text-base">قيّم الفني</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-1 justify-center">
              {[1,2,3,4,5].map((s) => (
                <Star
                  key={s}
                  className={`w-8 h-8 cursor-pointer ${s <= ratingStars ? "fill-primary text-primary" : "text-muted-foreground"}`}
                  onClick={() => setRatingStars(s)}
                />
              ))}
            </div>
            <Textarea
              placeholder="أضف تعليقك على الفني..."
              value={ratingReview}
              onChange={(e) => setRatingReview(e.target.value)}
            />
            <div className="flex gap-2">
              <Button onClick={handleSubmitRating} disabled={ratingMutation.isPending} className="flex-1">إرسال التقييم</Button>
              <Button variant="outline" onClick={() => setShowRating(false)}>تخطي</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
