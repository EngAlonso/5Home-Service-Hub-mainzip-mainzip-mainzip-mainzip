import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateRequest, useListServices, useListGovernorates, useListAreas, getListRequestsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  serviceId: z.string().min(1, "اختر الخدمة"),
  fullName: z.string().min(3, "الاسم مطلوب"),
  mobile: z.string().min(8, "رقم الهاتف مطلوب"),
  governorateId: z.string().min(1, "اختر المحافظة"),
  areaId: z.string().min(1, "اختر المنطقة"),
  address: z.string().min(5, "العنوان مطلوب"),
  description: z.string().min(10, "الوصف مطلوب"),
});

export default function CustomerNewRequest() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createMutation = useCreateRequest();

  const { data: services = [] } = useListServices();
  const { data: governorates = [] } = useListGovernorates();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { serviceId: "", fullName: "", mobile: "", governorateId: "", areaId: "", address: "", description: "" },
  });

  const selectedGovId = form.watch("governorateId");
  const { data: areas = [] } = useListAreas({ governorateId: selectedGovId ? parseInt(selectedGovId) : undefined } as any);

  const onSubmit = (values: z.infer<typeof schema>) => {
    createMutation.mutate(
      {
        data: {
          serviceId: parseInt(values.serviceId),
          fullName: values.fullName,
          mobile: values.mobile,
          governorateId: parseInt(values.governorateId),
          areaId: parseInt(values.areaId),
          address: values.address,
          description: values.description,
        } as any
      },
      {
        onSuccess: (res: any) => {
          queryClient.invalidateQueries({ queryKey: getListRequestsQueryKey() });
          toast({ title: "تم إنشاء الطلب", description: "سيتقدم الفنيون بعروضهم قريباً" });
          navigate(`/customer/requests/${res.id}`);
        },
        onError: (err: any) => {
          toast({ title: "خطأ", description: err?.data?.error || "حدث خطأ", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">طلب خدمة جديد</h1>
        <p className="text-muted-foreground text-sm mt-1">أملأ البيانات وسنجد لك أفضل الفنيين</p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField control={form.control} name="serviceId" render={({ field }) => (
                <FormItem>
                  <FormLabel>نوع الخدمة <span className="text-destructive">*</span></FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-service"><SelectValue placeholder="اختر الخدمة المطلوبة" /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {(services as any[]).filter((s: any) => s.isActive).map((s: any) => (
                        <SelectItem key={s.id} value={s.id.toString()}>{s.nameAr}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="fullName" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاسم الكامل <span className="text-destructive">*</span></FormLabel>
                    <FormControl><Input placeholder="اسمك" data-testid="input-fullname" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="mobile" render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم الهاتف <span className="text-destructive">*</span></FormLabel>
                    <FormControl><Input placeholder="01xxxxxxxxx" data-testid="input-mobile" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="governorateId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>المحافظة <span className="text-destructive">*</span></FormLabel>
                    <Select onValueChange={(v) => { field.onChange(v); form.setValue("areaId", ""); }} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-governorate"><SelectValue placeholder="اختر" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(governorates as any[]).map((g: any) => (
                          <SelectItem key={g.id} value={g.id.toString()}>{g.nameAr}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="areaId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>المنطقة <span className="text-destructive">*</span></FormLabel>
                    <Select onValueChange={field.onChange} value={field.value} disabled={!selectedGovId}>
                      <FormControl>
                        <SelectTrigger data-testid="select-area"><SelectValue placeholder="اختر" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(areas as any[]).map((a: any) => (
                          <SelectItem key={a.id} value={a.id.toString()}>{a.nameAr}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="address" render={({ field }) => (
                <FormItem>
                  <FormLabel>العنوان التفصيلي <span className="text-destructive">*</span></FormLabel>
                  <FormControl><Input placeholder="الشارع، البناية، الدور..." data-testid="input-address" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem>
                  <FormLabel>وصف المشكلة <span className="text-destructive">*</span></FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="صف المشكلة بالتفصيل لمساعدة الفنيين على تقديم عروض دقيقة..."
                      rows={4}
                      data-testid="textarea-description"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <Button type="submit" className="w-full font-bold py-5" disabled={createMutation.isPending} data-testid="button-submit">
                {createMutation.isPending ? "جاري الإرسال..." : "إرسال الطلب"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
