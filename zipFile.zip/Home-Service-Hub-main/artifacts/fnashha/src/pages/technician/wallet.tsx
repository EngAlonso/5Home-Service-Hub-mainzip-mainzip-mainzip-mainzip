import { useGetPointsBalance, getGetPointsBalanceQueryKey, useListPointTransactions, getListPointTransactionsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wallet, TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function TechnicianWallet() {
  const { data: balanceData } = useGetPointsBalance({ query: { queryKey: getGetPointsBalanceQueryKey() } });
  const { data: transactions = [] } = useListPointTransactions(
    undefined as any,
    { query: { queryKey: getListPointTransactionsQueryKey() } }
  );

  const balance = (balanceData as any)?.balance || 0;
  const txns = Array.isArray(transactions) ? transactions : [];

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">المحفظة</h1>

      {/* Balance card */}
      <Card className="bg-gradient-to-bl from-primary/30 to-primary/5 border-primary/20 mb-6">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
              <Wallet className="w-8 h-8 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">رصيد النقاط</p>
              <p className="text-4xl font-black text-foreground">{balance}</p>
              <p className="text-xs text-muted-foreground">نقطة متاحة للاستخدام</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">سجل المعاملات</CardTitle>
        </CardHeader>
        <CardContent>
          {txns.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد معاملات بعد</p>
          ) : (
            <div className="space-y-3">
              {txns.map((t: any) => {
                const isCredit = t.type === "credit";
                const isDebit = t.type === "debit";
                return (
                  <div key={t.id} className="flex items-center justify-between p-3 rounded-lg border border-border" data-testid={`txn-${t.id}`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center ${isCredit ? "bg-green-50" : isDebit ? "bg-red-50" : "bg-orange-50"}`}>
                        {isCredit ? <TrendingUp className="w-4 h-4 text-green-600" /> : isDebit ? <TrendingDown className="w-4 h-4 text-red-600" /> : <Minus className="w-4 h-4 text-orange-600" />}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{t.description}</p>
                        <p className="text-xs text-muted-foreground">{new Date(t.createdAt).toLocaleDateString("ar-EG")}</p>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className={`font-bold ${isCredit ? "text-green-600" : "text-red-600"}`}>
                        {isCredit ? "+" : "-"}{t.amount}
                      </p>
                      <p className="text-xs text-muted-foreground">الرصيد: {t.balanceAfter}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
