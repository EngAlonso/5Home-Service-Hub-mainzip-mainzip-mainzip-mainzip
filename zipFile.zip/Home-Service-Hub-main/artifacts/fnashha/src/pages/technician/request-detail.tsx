import { useState } from "react";
import { Link } from "wouter";
import {
  useGetRequest, getGetRequestQueryKey,
  useListOffers, getListOffersQueryKey,
  useCreateOffer,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { REQUEST_STATUS_MAP } from "@/lib/status";
import { MapPin, Phone, Clock, MessageCircle, Tag } from "lucide-react";

export default function TechnicianRequestDetail({ id }: { id: string }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { currentUser } = useAuth();
  const reqId = parseInt(id);
  const [price, setPrice] = useState("");
  const [notes, setNotes] = useState("");

  const { data: request, isLoading } = useGetRequest(reqId, {
    query: { enabled: !!reqId, queryKey: getGetRequestQueryKey(reqId) },
  });

  const { data: offers = [] } = useListOffers(
    { requestId: reqId } as any,
    { query: { enabled: !!reqId, queryKey: getListOffersQueryKey({ requestId: reqId } as any) } }
  );

  const createMutation = useCreateOffer();

  if (isLoading) return <div className="p-6 space-y-4">{[1,2].map((i) => <div key={i} className="h-28 bg-muted rounded-xl animate-pulse" />)}</div>;
  if (!request) return <div className="p-6 text-center text-muted-foreground">الطلب غير موجود</div>;

  const req = request as any;
  const statusInfo = REQUEST_STATUS_MAP[req.status] || { label: req.status, color: "bg-gray-100" };
  const myOffer = (offers as any[]).find((o: any) => o.technicianId === currentUser?.id);
  const canSubmitOffer = req.status === "pending" && !myOffer;
  const canChat = req.selectedTechnicianId === currentUser?.id &&
    ["technician_selected", "in_progress", "price_change_requested"].includes(req.status);

  const handleSubmitOffer = () => {
    if (!price) { toast({ title: "أدخل السعر", variant: "destructive" }); return; }
    createMutation.mutate(
      { requestId: reqId, data: { price: parseFloat(price), notes } as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetRequestQueryKey(reqId) });
          queryClient.invalidateQueries({ queryKey: getListOffersQueryKey({ requestId: reqId } as any) });
          toast({ title: "تم إرسال عرضك بنجاح" });
          setPrice(""); setNotes("");
        },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">طلب #{req.id}</h1>
          <Badge className={`mt-2 ${statusInfo.color} border-0`}>{statusInfo.label}</Badge>
        </div>
        {canChat && (
          <Link href={`/technician/chat/${reqId}`}>
            <Button size="sm" data-testid="button-chat">
              <MessageCircle className="w-4 h-4 ms-2" />
              المحادثة
            </Button>
          </Link>
        )}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">تفاصيل الطلب</CardTitle></CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-muted-foreground" />
            <span>{req.address}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-muted-foreground" />
            <span>{req.mobile}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span>{new Date(req.createdAt).toLocaleDateString("ar-EG")}</span>
          </div>
          <div className="pt-2 border-t">
            <p className="text-muted-foreground mb-1">وصف المشكلة:</p>
            <p>{req.description}</p>
          </div>
          {req.agreedPrice && (
            <div className="flex items-center gap-2 pt-2 border-t">
              <Tag className="w-4 h-4 text-primary" />
              <span className="font-semibold text-primary">السعر: {req.agreedPrice} جنيه</span>
            </div>
          )}
        </CardContent>
      </Card>

      {myOffer ? (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-5">
            <p className="font-semibold mb-2">عرضك المقدّم</p>
            <p className="text-2xl font-black text-primary">{myOffer.price} جنيه</p>
            {myOffer.notes && <p className="text-sm text-muted-foreground mt-2">{myOffer.notes}</p>}
            <Badge className="mt-3 text-xs">
              {myOffer.status === "pending" ? "في الانتظار" : myOffer.status === "selected" ? "تم اختيارك" : "مرفوض"}
            </Badge>
          </CardContent>
        </Card>
      ) : canSubmitOffer ? (
        <Card>
          <CardHeader><CardTitle className="text-base">تقديم عرضك</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">السعر (جنيه) *</label>
              <Input
                type="number"
                placeholder="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="mt-1"
                data-testid="input-price"
              />
            </div>
            <div>
              <label className="text-sm font-medium">ملاحظات (اختياري)</label>
              <Textarea
                placeholder="أضف تفاصيل عن عرضك..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mt-1"
                rows={3}
                data-testid="textarea-notes"
              />
            </div>
            <Button
              className="w-full font-bold"
              onClick={handleSubmitOffer}
              disabled={createMutation.isPending}
              data-testid="button-submit-offer"
            >
              {createMutation.isPending ? "جاري الإرسال..." : "إرسال العرض"}
            </Button>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
