import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  useListServices, getListServicesQueryKey,
  useCreateService, useUpdateService, useDeleteService,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { PlusCircle, Pencil, Trash2, Settings2 } from "lucide-react";

const schema = z.object({
  name: z.string().min(2),
  nameAr: z.string().min(2, "الاسم العربي مطلوب"),
  icon: z.string().optional(),
  displayOrder: z.number().optional(),
});

export default function AdminServices() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);

  const { data: services = [], isLoading } = useListServices({
    query: { queryKey: getListServicesQueryKey() },
  });

  const createMutation = useCreateService();
  const updateMutation = useUpdateService();
  const deleteMutation = useDeleteService();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", nameAr: "", icon: "", displayOrder: 0 },
  });

  const openCreate = () => { setEditing(null); form.reset({ name: "", nameAr: "", icon: "", displayOrder: 0 }); setShowForm(true); };
  const openEdit = (s: any) => { setEditing(s); form.reset({ name: s.name, nameAr: s.nameAr, icon: s.icon || "", displayOrder: s.displayOrder || 0 }); setShowForm(true); };

  const onSubmit = (values: z.infer<typeof schema>) => {
    const mutation = editing ? updateMutation.mutate : createMutation.mutate;
    const args = editing
      ? { id: editing.id, data: values as any }
      : { data: values as any };

    if (editing) {
      updateMutation.mutate(
        { id: editing.id, data: values as any },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListServicesQueryKey() });
            toast({ title: "تم الحفظ" });
            setShowForm(false);
          },
        }
      );
    } else {
      createMutation.mutate(
        { data: values as any },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListServicesQueryKey() });
            toast({ title: "تم إضافة الخدمة" });
            setShowForm(false);
          },
        }
      );
    }
  };

  const handleDelete = (id: number) => {
    if (!confirm("هل أنت متأكد من الحذف؟")) return;
    deleteMutation.mutate(
      { id } as any,
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListServicesQueryKey() });
          toast({ title: "تم الحذف" });
        },
      }
    );
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">الخدمات</h1>
          <p className="text-muted-foreground text-sm">{(services as any[]).length} خدمة مسجلة</p>
        </div>
        <Button onClick={openCreate} data-testid="button-add-service">
          <PlusCircle className="w-4 h-4 ms-2" />
          إضافة خدمة
        </Button>
      </div>

      {showForm && (
        <Card className="mb-6 border-primary/20">
          <CardHeader>
            <CardTitle className="text-base">{editing ? "تعديل الخدمة" : "إضافة خدمة جديدة"}</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="nameAr" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاسم العربي *</FormLabel>
                    <FormControl><Input placeholder="كهرباء" data-testid="input-name-ar" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاسم الإنجليزي *</FormLabel>
                    <FormControl><Input placeholder="Electricity" data-testid="input-name" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="icon" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الأيقونة</FormLabel>
                    <FormControl><Input placeholder="⚡" data-testid="input-icon" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <div className="flex items-end gap-2">
                  <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save">
                    {editing ? "حفظ" : "إضافة"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-2">{[1,2,3].map((i) => <div key={i} className="h-14 bg-muted rounded-lg animate-pulse" />)}</div>
      ) : (
        <div className="space-y-2">
          {(services as any[]).map((s: any) => (
            <Card key={s.id} data-testid={`row-service-${s.id}`}>
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{s.icon || "🔧"}</span>
                  <div>
                    <p className="font-medium">{s.nameAr}</p>
                    <p className="text-xs text-muted-foreground">{s.name}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={s.isActive ? "bg-green-100 text-green-800 border-0" : "bg-gray-100 text-gray-600 border-0"}>
                    {s.isActive ? "نشط" : "مخفي"}
                  </Badge>
                  <Button size="sm" variant="ghost" onClick={() => openEdit(s)} data-testid={`button-edit-${s.id}`}>
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDelete(s.id)} data-testid={`button-delete-${s.id}`}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
