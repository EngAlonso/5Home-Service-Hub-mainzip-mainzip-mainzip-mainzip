import { useState } from "react";
import { Link } from "wouter";
import {
  useListUsers, getListUsersQueryKey,
  useListPendingTechnicians, getListPendingTechniciansQueryKey,
  useApproveTechnician, useRejectTechnician,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Search, CheckCircle, XCircle, ChevronLeft, Edit2, ShieldBan, ShieldCheck, UserX } from "lucide-react";
import { useAuth } from "@/contexts/auth-context";

const BASE_URL = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

async function apiCall(path: string, method: string, body?: any, token?: string) {
  const res = await fetch(`${BASE_URL}/api${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "خطأ في الخادم");
  return data;
}

const STATUS_LABEL: Record<string, { label: string; cls: string }> = {
  active:    { label: "نشط",     cls: "bg-green-100 text-green-800" },
  suspended: { label: "موقوف",   cls: "bg-yellow-100 text-yellow-800" },
  banned:    { label: "محظور",   cls: "bg-red-100 text-red-800" },
  pending:   { label: "بانتظار الموافقة", cls: "bg-blue-100 text-blue-800" },
  rejected:  { label: "مرفوض",  cls: "bg-red-100 text-red-800" },
};

export default function AdminTechnicians() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { token } = useAuth();
  const [tab, setTab] = useState<"all" | "pending">("pending");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);

  // Edit state
  const [editFullName, setEditFullName] = useState("");
  const [editMobile, setEditMobile] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editPassword, setEditPassword] = useState("");

  // Ban state
  const [banType, setBanType] = useState<"temporary" | "permanent">("temporary");
  const [banDays, setBanDays] = useState("7");
  const [banReason, setBanReason] = useState("");

  const { data: pendingTechs = [], isLoading: pendingLoading } = useListPendingTechnicians({
    query: { queryKey: getListPendingTechniciansQueryKey() },
  });
  const { data, isLoading: allLoading } = useListUsers(
    { role: "technician", search: search || undefined } as any,
    { query: { queryKey: getListUsersQueryKey({ role: "technician" } as any) } }
  );

  const allTechs = (data as any)?.data || [];
  const pending = Array.isArray(pendingTechs) ? pendingTechs : [];
  const approveMutation = useApproveTechnician();
  const rejectMutation = useRejectTechnician();

  const handleApprove = (id: number) => {
    approveMutation.mutate(
      { id, data: {} as any },
      {
        onSuccess: () => { qc.invalidateQueries({ queryKey: getListPendingTechniciansQueryKey() }); toast({ title: "تم الموافقة على الفني" }); },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  const handleReject = (id: number) => {
    rejectMutation.mutate(
      { id, data: { reason: "لم يستوف الشروط" } as any },
      {
        onSuccess: () => { qc.invalidateQueries({ queryKey: getListPendingTechniciansQueryKey() }); toast({ title: "تم رفض الطلب" }); },
      }
    );
  };

  const openManage = (user: any) => {
    setSelected(user);
    setEditFullName(user.fullName || "");
    setEditMobile(user.mobile || "");
    setEditEmail(user.email || "");
    setEditPassword("");
    setBanType("temporary");
    setBanDays("7");
    setBanReason("");
  };

  const invalidateAll = () => {
    qc.invalidateQueries({ queryKey: getListUsersQueryKey({ role: "technician" } as any) });
    qc.invalidateQueries({ queryKey: getListPendingTechniciansQueryKey() });
  };

  const handleEdit = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      await apiCall(`/users/${selected.id}/admin-edit`, "PATCH", {
        fullName: editFullName,
        mobile: editMobile,
        email: editEmail,
        newPassword: editPassword || undefined,
      }, token || "");
      toast({ title: "تم تحديث بيانات الفني" });
      invalidateAll();
      setSelected(null);
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleBan = async () => {
    if (!selected || !banReason.trim()) {
      toast({ title: "يرجى كتابة سبب الإيقاف", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      await apiCall(`/users/${selected.id}/ban`, "POST", {
        type: banType,
        days: banType === "temporary" ? parseInt(banDays) : undefined,
        reason: banReason,
      }, token || "");
      toast({ title: banType === "permanent" ? "تم حظر الحساب بشكل دائم" : `تم إيقاف الحساب لمدة ${banDays} أيام` });
      invalidateAll();
      setSelected(null);
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleUnban = async (id: number) => {
    setLoading(true);
    try {
      await apiCall(`/users/${id}/unban`, "POST", {}, token || "");
      toast({ title: "تم رفع الإيقاف" });
      invalidateAll();
      setSelected(null);
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">إدارة الفنيين</h1>
        <p className="text-muted-foreground text-sm mt-1">مراجعة وإدارة الفنيين المسجلين</p>
      </div>

      <div className="flex gap-2 mb-5">
        <Button variant={tab === "pending" ? "default" : "outline"} size="sm" onClick={() => setTab("pending")} data-testid="tab-pending">
          بانتظار الموافقة {pending.length > 0 && `(${pending.length})`}
        </Button>
        <Button variant={tab === "all" ? "default" : "outline"} size="sm" onClick={() => setTab("all")} data-testid="tab-all">
          جميع الفنيين
        </Button>
      </div>

      {tab === "pending" && (
        <div className="space-y-3">
          {pendingLoading ? (
            [1, 2, 3].map((i) => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)
          ) : pending.length === 0 ? (
            <Card><CardContent className="py-14 text-center text-muted-foreground">لا يوجد طلبات معلقة</CardContent></Card>
          ) : (
            pending.map((t: any) => (
              <Card key={t.id} data-testid={`card-pending-${t.id}`}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{t.user?.fullName}</p>
                    <p className="text-sm text-muted-foreground">{t.user?.mobile}</p>
                    <p className="text-xs text-muted-foreground">رقم البطاقة: {t.nationalId}</p>
                  </div>
                  <div className="flex gap-2">
                    <Link href={`/admin/technicians/${t.userId}`}>
                      <Button size="sm" variant="outline" data-testid={`button-view-${t.id}`}>
                        <ChevronLeft className="w-3 h-3" />
                      </Button>
                    </Link>
                    <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => handleApprove(t.userId)} disabled={approveMutation.isPending} data-testid={`button-approve-${t.id}`}>
                      <CheckCircle className="w-3 h-3 ms-1" /> موافقة
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleReject(t.userId)} disabled={rejectMutation.isPending} data-testid={`button-reject-${t.id}`}>
                      <XCircle className="w-3 h-3 ms-1" /> رفض
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {tab === "all" && (
        <>
          <div className="relative mb-4">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="بحث..." value={search} onChange={(e) => setSearch(e.target.value)} className="pr-9" data-testid="input-search" />
          </div>
          <div className="space-y-2">
            {allLoading ? (
              [1, 2, 3].map((i) => <div key={i} className="h-14 bg-muted rounded-lg animate-pulse" />)
            ) : allTechs.map((user: any) => {
              const st = STATUS_LABEL[user.status] || { label: user.status, cls: "bg-gray-100 text-gray-800" };
              const isBanned = user.status === "banned" || user.status === "suspended";
              return (
                <Card key={user.id} className="hover:border-primary/30 transition-all" data-testid={`row-tech-${user.id}`}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium">{user.fullName}</p>
                      <p className="text-sm text-muted-foreground">{user.mobile}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`${st.cls} border-0 text-xs`}>{st.label}</Badge>
                      <Link href={`/admin/technicians/${user.id}`}>
                        <Button size="sm" variant="ghost">
                          <ChevronLeft className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Button size="sm" variant="outline" onClick={() => openManage(user)} data-testid={`button-manage-${user.id}`}>
                        <Edit2 className="w-3 h-3 ms-1" /> إدارة
                      </Button>
                      {isBanned && (
                        <Button size="sm" variant="outline" className="text-green-700 border-green-300 hover:bg-green-50" onClick={() => handleUnban(user.id)} disabled={loading} data-testid={`button-unban-${user.id}`}>
                          <ShieldCheck className="w-3 h-3 ms-1" /> رفع الإيقاف
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {/* Manage Technician Dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => { if (!open) setSelected(null); }}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>إدارة حساب: {selected?.fullName}</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="edit">
            <TabsList className="w-full">
              <TabsTrigger value="edit" className="flex-1">تعديل البيانات</TabsTrigger>
              <TabsTrigger value="ban" className="flex-1">إيقاف / حظر</TabsTrigger>
            </TabsList>

            <TabsContent value="edit" className="space-y-3 mt-4">
              <div>
                <Label>الاسم الكامل</Label>
                <Input value={editFullName} onChange={(e) => setEditFullName(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>رقم الهاتف</Label>
                <Input value={editMobile} onChange={(e) => setEditMobile(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>البريد الإلكتروني</Label>
                <Input value={editEmail} onChange={(e) => setEditEmail(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>كلمة مرور جديدة <span className="text-muted-foreground text-xs">(اتركه فارغاً)</span></Label>
                <Input type="password" value={editPassword} onChange={(e) => setEditPassword(e.target.value)} className="mt-1" placeholder="••••••••" />
              </div>
              <Button className="w-full" onClick={handleEdit} disabled={loading}>
                {loading ? "جاري الحفظ..." : "حفظ التعديلات"}
              </Button>
            </TabsContent>

            <TabsContent value="ban" className="space-y-3 mt-4">
              {(selected?.status === "banned" || selected?.status === "suspended") ? (
                <div className="text-center space-y-3">
                  <div className="p-4 bg-red-50 rounded-lg">
                    <ShieldBan className="w-8 h-8 text-red-500 mx-auto mb-2" />
                    <p className="font-medium text-red-800">الحساب موقوف</p>
                    {selected?.suspensionReason && <p className="text-sm text-red-600 mt-1">السبب: {selected.suspensionReason}</p>}
                    {selected?.bannedUntil && selected?.status === "suspended" && (
                      <p className="text-xs text-red-500 mt-1">حتى: {new Date(selected.bannedUntil).toLocaleDateString("ar-EG")}</p>
                    )}
                  </div>
                  <Button variant="outline" className="w-full text-green-700 border-green-300" onClick={() => handleUnban(selected?.id)} disabled={loading}>
                    <ShieldCheck className="w-4 h-4 ms-2" />
                    رفع الإيقاف
                  </Button>
                </div>
              ) : (
                <>
                  <div>
                    <Label>نوع الإيقاف</Label>
                    <Select value={banType} onValueChange={(v: any) => setBanType(v)}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="temporary">مؤقت</SelectItem>
                        <SelectItem value="permanent">دائم</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {banType === "temporary" && (
                    <div>
                      <Label>المدة</Label>
                      <Select value={banDays} onValueChange={setBanDays}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">يوم واحد</SelectItem>
                          <SelectItem value="3">3 أيام</SelectItem>
                          <SelectItem value="7">أسبوع</SelectItem>
                          <SelectItem value="14">أسبوعان</SelectItem>
                          <SelectItem value="30">شهر</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div>
                    <Label>سبب الإيقاف <span className="text-destructive">*</span></Label>
                    <Textarea value={banReason} onChange={(e) => setBanReason(e.target.value)} className="mt-1" rows={2} placeholder="اكتب سبب الإيقاف..." />
                  </div>
                  <Button variant="destructive" className="w-full" onClick={handleBan} disabled={loading}>
                    <UserX className="w-4 h-4 ms-2" />
                    {loading ? "جاري التنفيذ..." : banType === "permanent" ? "حظر دائم" : `إيقاف لمدة ${banDays} أيام`}
                  </Button>
                </>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
