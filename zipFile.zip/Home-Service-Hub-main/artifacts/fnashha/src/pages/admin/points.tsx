import { useState } from "react";
import {
  useAddPoints, useDeductPoints,
  useListPointTransactions, getListPointTransactionsQueryKey,
  useListUsers,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Coins, TrendingUp, TrendingDown } from "lucide-react";

export default function AdminPoints() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [techMobile, setTechMobile] = useState("");
  const [techId, setTechId] = useState<number | null>(null);
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");

  const { data: allTechs } = useListUsers({ role: "technician" } as any);
  const { data: transactions = [] } = useListPointTransactions(
    undefined as any,
    { query: { queryKey: getListPointTransactionsQueryKey() } }
  );

  const addMutation = useAddPoints();
  const deductMutation = useDeductPoints();

  const techs = (allTechs as any)?.data || [];

  const findTech = () => {
    const tech = techs.find((t: any) => t.mobile === techMobile);
    if (tech) setTechId(tech.id);
    else toast({ title: "الفني غير موجود", variant: "destructive" });
  };

  const selectedTech = techs.find((t: any) => t.id === techId);
  const txns = Array.isArray(transactions) ? transactions : [];

  const handleAdd = () => {
    if (!techId || !amount) { toast({ title: "أدخل البيانات المطلوبة", variant: "destructive" }); return; }
    addMutation.mutate(
      { data: { technicianId: techId, amount: parseInt(amount), description } as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPointTransactionsQueryKey() });
          toast({ title: "تم إضافة النقاط" });
          setAmount(""); setDescription("");
        },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  const handleDeduct = () => {
    if (!techId || !amount) { toast({ title: "أدخل البيانات المطلوبة", variant: "destructive" }); return; }
    deductMutation.mutate(
      { data: { technicianId: techId, amount: parseInt(amount), description } as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPointTransactionsQueryKey() });
          toast({ title: "تم خصم النقاط" });
          setAmount(""); setDescription("");
        },
        onError: (err: any) => toast({ title: "خطأ", description: err?.data?.error, variant: "destructive" }),
      }
    );
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">إدارة النقاط</h1>

      {/* Controls */}
      <Card className="mb-6">
        <CardHeader><CardTitle className="text-base">إضافة / خصم نقاط</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="رقم هاتف الفني"
              value={techMobile}
              onChange={(e) => setTechMobile(e.target.value)}
              data-testid="input-tech-mobile"
            />
            <Button variant="outline" onClick={findTech} data-testid="button-find-tech">بحث</Button>
          </div>

          {selectedTech && (
            <div className="bg-primary/5 rounded-lg p-3 text-sm">
              <p className="font-semibold">{selectedTech.fullName}</p>
              <p className="text-muted-foreground">{selectedTech.mobile}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">الكمية *</label>
              <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="100" className="mt-1" data-testid="input-amount" />
            </div>
            <div>
              <label className="text-sm font-medium">السبب</label>
              <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="سبب الإضافة/الخصم" className="mt-1" data-testid="input-description" />
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={handleAdd}
              disabled={addMutation.isPending || !techId}
              data-testid="button-add"
            >
              <TrendingUp className="w-4 h-4 ms-2" />
              إضافة نقاط
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeduct}
              disabled={deductMutation.isPending || !techId}
              data-testid="button-deduct"
            >
              <TrendingDown className="w-4 h-4 ms-2" />
              خصم نقاط
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent transactions */}
      <Card>
        <CardHeader><CardTitle className="text-base">آخر المعاملات</CardTitle></CardHeader>
        <CardContent>
          {txns.length === 0 ? (
            <p className="text-center text-muted-foreground py-8 text-sm">لا توجد معاملات</p>
          ) : (
            <div className="space-y-2">
              {txns.slice(0, 20).map((t: any) => (
                <div key={t.id} className="flex items-center justify-between p-3 rounded-lg border border-border text-sm" data-testid={`txn-${t.id}`}>
                  <div>
                    <p className="font-medium">{t.description}</p>
                    <p className="text-xs text-muted-foreground">{new Date(t.createdAt).toLocaleDateString("ar-EG")}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`font-bold ${t.type === "credit" ? "text-green-600" : "text-red-600"}`}>
                      {t.type === "credit" ? "+" : "-"}{t.amount}
                    </span>
                    <Badge variant="outline" className="text-xs">رصيد: {t.balanceAfter}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
