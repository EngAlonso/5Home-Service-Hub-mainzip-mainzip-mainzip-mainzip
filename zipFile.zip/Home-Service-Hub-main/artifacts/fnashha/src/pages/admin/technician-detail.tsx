import {
  useGetUser, getGetUserQueryKey,
  useGetTechnicianProfile, getGetTechnicianProfileQueryKey,
  useApproveTechnician, useRejectTechnician,
  getListPendingTechniciansQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { APPROVAL_STATUS_MAP } from "@/lib/status";
import { Star, CheckCircle, XCircle, Wallet } from "lucide-react";

export default function AdminTechnicianDetail({ id }: { id: string }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const userId = parseInt(id);

  const { data: user } = useGetUser(userId, { query: { enabled: !!userId, queryKey: getGetUserQueryKey(userId) } });
  const { data: profile } = useGetTechnicianProfile(userId, { query: { enabled: !!userId, queryKey: getGetTechnicianProfileQueryKey(userId) } });

  const approveMutation = useApproveTechnician();
  const rejectMutation = useRejectTechnician();

  const u = user as any;
  const p = profile as any;
  const approvalInfo = APPROVAL_STATUS_MAP[p?.approvalStatus] || { label: "—", color: "bg-gray-100" };

  const handleApprove = () => {
    approveMutation.mutate(
      { id: userId, data: {} as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetTechnicianProfileQueryKey(userId) });
          queryClient.invalidateQueries({ queryKey: getListPendingTechniciansQueryKey() });
          toast({ title: "تم الموافقة" });
        },
      }
    );
  };

  const handleReject = () => {
    rejectMutation.mutate(
      { id: userId, data: { reason: "لم يستوف الشروط" } as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetTechnicianProfileQueryKey(userId) });
          queryClient.invalidateQueries({ queryKey: getListPendingTechniciansQueryKey() });
          toast({ title: "تم الرفض" });
        },
      }
    );
  };

  if (!u) return <div className="p-6 text-center text-muted-foreground">جاري التحميل...</div>;

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">{u.fullName}</h1>
          <p className="text-muted-foreground">{u.mobile}</p>
        </div>
        <div className="flex gap-2">
          {p?.approvalStatus === "pending" && (
            <>
              <Button
                className="bg-green-600 hover:bg-green-700 text-white"
                size="sm"
                onClick={handleApprove}
                disabled={approveMutation.isPending}
                data-testid="button-approve"
              >
                <CheckCircle className="w-4 h-4 ms-1" /> موافقة
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={handleReject}
                disabled={rejectMutation.isPending}
                data-testid="button-reject"
              >
                <XCircle className="w-4 h-4 ms-1" /> رفض
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">حالة الموافقة</p>
            <Badge className={`mt-1 ${approvalInfo.color} border-0`}>{approvalInfo.label}</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-primary" />
            <div>
              <p className="font-bold">{p?.pointsBalance || 0}</p>
              <p className="text-xs text-muted-foreground">نقاط</p>
            </div>
          </CardContent>
        </Card>
        {p?.averageRating > 0 && (
          <Card>
            <CardContent className="p-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-primary fill-primary" />
              <div>
                <p className="font-bold">{p.averageRating?.toFixed(1)}</p>
                <p className="text-xs text-muted-foreground">{p.reviewCount} تقييم</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {p && (
        <Card>
          <CardHeader><CardTitle className="text-base">بيانات الفني</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div><span className="text-muted-foreground">رقم البطاقة: </span>{p.nationalId}</div>
            {u.email && <div><span className="text-muted-foreground">البريد: </span>{u.email}</div>}
            {p.rejectionReason && (
              <div className="bg-red-50 text-red-700 rounded-lg p-3 text-sm">
                <p className="font-semibold">سبب الرفض:</p>
                <p>{p.rejectionReason}</p>
              </div>
            )}

            {p.services && p.services.length > 0 && (
              <div>
                <p className="font-medium mb-2">الخدمات:</p>
                <div className="flex flex-wrap gap-2">
                  {p.services.map((s: any) => s && <Badge key={s.id} variant="secondary">{s.nameAr}</Badge>)}
                </div>
              </div>
            )}

            {p.areas && p.areas.length > 0 && (
              <div>
                <p className="font-medium mb-2">المناطق:</p>
                <div className="flex flex-wrap gap-2">
                  {p.areas.map((a: any) => a && <Badge key={a.id} variant="outline">{a.nameAr}</Badge>)}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
