import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Wrench, ChevronLeft } from "lucide-react";

export default function Register() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-xl">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Wrench className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-black text-foreground">مرحباً بك في فنشها</h1>
          <p className="text-muted-foreground mt-2">اختر نوع حسابك للبدء</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Link href="/register/customer">
            <Card className="cursor-pointer hover:border-primary hover:shadow-xl transition-all duration-200 group" data-testid="card-register-customer">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5 group-hover:bg-primary/20 transition-colors">
                  <User className="w-10 h-10 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-2">عميل</h2>
                <p className="text-muted-foreground text-sm mb-6">أبحث عن خدمات منزلية احترافية وأريد استقبال عروض من الفنيين</p>
                <Button className="w-full font-semibold" variant="outline">
                  سجّل كعميل
                  <ChevronLeft className="w-4 h-4 me-2" />
                </Button>
              </CardContent>
            </Card>
          </Link>

          <Link href="/register/technician">
            <Card className="cursor-pointer hover:border-primary hover:shadow-xl transition-all duration-200 group" data-testid="card-register-technician">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5 group-hover:bg-primary/20 transition-colors">
                  <Wrench className="w-10 h-10 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-2">فني</h2>
                <p className="text-muted-foreground text-sm mb-6">أقدم خدمات منزلية وأريد عرض مهاراتي لاستقبال طلبات العملاء</p>
                <Button className="w-full font-semibold">
                  سجّل كفني
                  <ChevronLeft className="w-4 h-4 me-2" />
                </Button>
              </CardContent>
            </Card>
          </Link>
        </div>

        <p className="text-center text-muted-foreground text-sm mt-8">
          لديك حساب بالفعل؟{" "}
          <Link href="/login" className="text-primary font-semibold hover:underline">تسجيل الدخول</Link>
        </p>
      </div>
    </div>
  );
}
