import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { useRegisterTechnician, useListServices, useListGovernorates, useListAreas } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Wrench } from "lucide-react";

const schema = z.object({
  fullName: z.string().min(3, "الاسم يجب أن يكون 3 أحرف على الأقل"),
  mobile: z.string().min(8, "رقم الهاتف غير صحيح"),
  nationalId: z.string().min(14, "رقم البطاقة غير صحيح"),
  password: z.string().min(6, "كلمة المرور قصيرة جداً"),
  confirmPassword: z.string(),
  primaryGovernorateId: z.string().min(1, "اختر المحافظة"),
  primaryAreaId: z.string().min(1, "اختر المنطقة"),
}).refine((d) => d.password === d.confirmPassword, {
  message: "كلمتا المرور غير متطابقتان",
  path: ["confirmPassword"],
});

export default function RegisterTechnician() {
  const [, navigate] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const registerMutation = useRegisterTechnician();
  const [selectedServiceIds, setSelectedServiceIds] = useState<number[]>([]);
  const [selectedAreaIds, setSelectedAreaIds] = useState<number[]>([]);

  const { data: services = [] } = useListServices();
  const { data: governorates = [] } = useListGovernorates();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: {
      fullName: "", mobile: "", nationalId: "", password: "", confirmPassword: "",
      primaryGovernorateId: "", primaryAreaId: "",
    },
  });

  const selectedGovId = form.watch("primaryGovernorateId");
  const { data: areas = [] } = useListAreas({ governorateId: selectedGovId ? parseInt(selectedGovId) : undefined } as any);

  const toggleService = (id: number) => {
    setSelectedServiceIds((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]);
  };
  const toggleArea = (id: number) => {
    setSelectedAreaIds((prev) => prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]);
  };

  const onSubmit = (values: z.infer<typeof schema>) => {
    if (selectedServiceIds.length === 0) {
      toast({ title: "اختر خدمة واحدة على الأقل", variant: "destructive" }); return;
    }
    const data = {
      fullName: values.fullName,
      mobile: values.mobile,
      nationalId: values.nationalId,
      password: values.password,
      serviceIds: selectedServiceIds,
      areaIds: selectedAreaIds.length > 0 ? selectedAreaIds : [parseInt(values.primaryAreaId)],
      primaryAreaId: parseInt(values.primaryAreaId),
    };
    registerMutation.mutate(
      { data: data as any },
      {
        onSuccess: (res: any) => {
          login(res.token, res.user);
          navigate("/technician");
        },
        onError: (err: any) => {
          toast({ title: "خطأ في التسجيل", description: err?.data?.error || "حدث خطأ", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-lg">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <Wrench className="w-7 h-7 text-primary" />
          </div>
          <h1 className="text-2xl font-black text-foreground">تسجيل فني جديد</h1>
          <p className="text-muted-foreground text-sm mt-1">سيتم مراجعة طلبك من قبل الإدارة</p>
        </div>

        <Card className="shadow-lg">
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="fullName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>الاسم الكامل</FormLabel>
                      <FormControl><Input placeholder="محمد أحمد" data-testid="input-fullname" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="mobile" render={({ field }) => (
                    <FormItem>
                      <FormLabel>رقم الهاتف</FormLabel>
                      <FormControl><Input placeholder="01xxxxxxxxx" data-testid="input-mobile" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="nationalId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم البطاقة القومية</FormLabel>
                    <FormControl><Input placeholder="14 رقم" data-testid="input-national-id" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="password" render={({ field }) => (
                    <FormItem>
                      <FormLabel>كلمة المرور</FormLabel>
                      <FormControl><Input type="password" placeholder="••••••••" data-testid="input-password" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="confirmPassword" render={({ field }) => (
                    <FormItem>
                      <FormLabel>تأكيد المرور</FormLabel>
                      <FormControl><Input type="password" placeholder="••••••••" data-testid="input-confirm-password" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>

                {/* Services */}
                <div>
                  <p className="text-sm font-medium leading-none mb-2">الخدمات المقدمة <span className="text-destructive">*</span></p>
                  <div className="grid grid-cols-2 gap-2 mt-2 max-h-40 overflow-y-auto border rounded-lg p-3">
                    {(services as any[]).filter((s: any) => s.isActive).map((service: any) => (
                      <label key={service.id} className="flex items-center gap-2 cursor-pointer text-sm" data-testid={`checkbox-service-${service.id}`}>
                        <Checkbox
                          checked={selectedServiceIds.includes(service.id)}
                          onCheckedChange={() => toggleService(service.id)}
                        />
                        {service.nameAr}
                      </label>
                    ))}
                  </div>
                </div>

                {/* Location */}
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="primaryGovernorateId" render={({ field }) => (
                    <FormItem>
                      <FormLabel>المحافظة</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-governorate"><SelectValue placeholder="اختر" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(governorates as any[]).map((g: any) => (
                            <SelectItem key={g.id} value={g.id.toString()}>{g.nameAr}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="primaryAreaId" render={({ field }) => (
                    <FormItem>
                      <FormLabel>المنطقة الرئيسية</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value} disabled={!selectedGovId}>
                        <FormControl>
                          <SelectTrigger data-testid="select-area"><SelectValue placeholder="اختر" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(areas as any[]).map((a: any) => (
                            <SelectItem key={a.id} value={a.id.toString()}>{a.nameAr}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>

                <Button type="submit" className="w-full font-bold py-5" disabled={registerMutation.isPending} data-testid="button-submit">
                  {registerMutation.isPending ? "جاري التسجيل..." : "تقديم طلب التسجيل"}
                </Button>
              </form>
            </Form>
            <p className="text-center text-sm text-muted-foreground mt-4">
              لديك حساب؟ <Link href="/login" className="text-primary font-semibold">دخول</Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
